#include "tay_nguyen_campaign.h"

////////////////////////////////////////////////////////////////////////
/// STUDENT'S ANSWER BEGINS HERE
/// Complete the following functions
/// DO NOT modify any parameters in the functions.
////////////////////////////////////////////////////////////////////////

const int MAX_LINES = 5;
const int MAX_LINE_LENGTH = 100;

// Task 0
bool readFile(const string &filename, int LF1[], int LF2[], int &EXP1,
              int &EXP2, int &T1, int &T2, int &E) {
  // TODO Task 0
  return 0;
}

// Task 1: Gather Forces
int gatherForces(int LF1[], int LF2[]) {
  // TODO Task 1
  return 0;
}

// Task 2: Deception Strategy
string determineRightTarget(const string &target) { return ""; }
string decodeTarget(const string &message, int EXP1, int EXP2) {
  // TODO Task 2
  return "";
}

// Task 3: Logistics Management
void manageLogistics(int LF1, int LF2, int EXP1, int EXP2, int &T1, int &T2,
                     int E) {
  // TODO Task 3
}

// Task 4: Attack Planning
int planAttack(int LF1, int LF2, int EXP1, int EXP2, int T1, int T2,
               int battleField[10][10]) {
  // TODO Task 4
  return 1;
}

// Task 5: Resupply
int resupply(int shortfall, int supply[5][5]) {
  // TODO Task 5
  return 1;
}

////////////////////////////////////////////////
/// END OF STUDENT'S ANSWER
////////////////////////////////////////////////
