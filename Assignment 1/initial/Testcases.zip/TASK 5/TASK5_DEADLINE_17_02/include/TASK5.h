#include <climits>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;
// The library here is concretely set, students are not allowed to include any
// other libraries

// Task 5: Resupply
int resupply(int shortfall, int supply[5][5]);
