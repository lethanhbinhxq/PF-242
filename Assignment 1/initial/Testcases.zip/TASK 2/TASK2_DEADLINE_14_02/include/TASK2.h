#include <climits>
#include <cmath>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;
// The library here is concretely set, students are not allowed to include any
// other libraries

// Task 2: Deception Strategy
string determineRightTarget(const string &target);
string decodeTarget(const string &message, int EXP1, int EXP2);
