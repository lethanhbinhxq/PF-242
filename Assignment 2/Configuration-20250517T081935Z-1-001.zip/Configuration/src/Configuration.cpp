#include "Configuration.h"
void processFile(const string &filename, TerrainType **&battlefield, int &NUM_ROWS, int &NUM_COLS, vector<UNIT_NAME> &units, int &EVENT_CODE) {
    // TODO
}
string print_battlefield(const TerrainType **battlefield, const int &NUM_ROWS, const int &NUM_COLS){
    stringstream ss;
    ss << "VOTIEN";
    // TODO
    return ss.str();  
}
string print_UNIT_NAME(const vector<UNIT_NAME> &units) {
    stringstream ss;
    ss << "VOTIEN";
    // TODO
    return ss.str();
}
void clearBattlefield(TerrainType **battlefield, const int &NUM_ROWS, const int &NUM_COLS) {
    // TODO
}
