#include "Position.h"

Position::Position(int r, int c) : r(r), c(c)
{
    // TODO: implement
}

Position::Position(const string &str_pos)
{
    // TODO: implement
}

int Position::getRow() const { return r; }

int Position::getCol() const { return c; }

void Position::setRow(int r)
{ // TODO: implement
}

void Position::setCol(int c)
{
    // TODO: implement
}

string Position::str() const
{
    // TODO: implement
    return "";
}