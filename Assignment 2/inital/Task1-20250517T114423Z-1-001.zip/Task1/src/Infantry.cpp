#include "Infantry.h"

// TODO: implement