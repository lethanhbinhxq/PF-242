#include "Unit.h"

Unit::Unit(int quantity, int weight, Position pos)
{
    // TODO: implement
}

Unit::~Unit()
{
    // TODO: implement
}

Position Unit::getCurrentPosition() const
{
    return pos;
}