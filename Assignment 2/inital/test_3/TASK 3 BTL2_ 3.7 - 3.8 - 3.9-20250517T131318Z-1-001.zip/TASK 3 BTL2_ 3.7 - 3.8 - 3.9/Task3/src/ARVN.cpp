#include "ARVN.h"

// TODO: Implement
ARVN::ARVN(Unit** unitArray, int size, string name, BattleField *battleField) 
        : Army(unitArray, size, name, battleField) {
}

void ARVN::fight(Army* enemy, bool defense) {
}

string ARVN::str() const {
}
