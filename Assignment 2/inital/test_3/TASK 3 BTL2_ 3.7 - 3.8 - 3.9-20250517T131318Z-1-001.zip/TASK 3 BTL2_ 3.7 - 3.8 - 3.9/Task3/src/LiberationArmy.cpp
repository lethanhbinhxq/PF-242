#include "LiberationArmy.h"


// TODO: Implement
// class LiberationArmy
LiberationArmy::LiberationArmy(Unit **unitArray, int size, string name, BattleField *battleField)
                                                : Army(unitArray,size,name, battleField) {
}

void LiberationArmy::fight(Army *enemy, bool defense){
}

string LiberationArmy::str() const {
}
