#include "LiberationArmy.h"

// TODO: Implement
// class LiberationArmy
LiberationArmy::LiberationArmy(Unit **unitArray, int size, string name)
                                                : Army(unitArray,size,name) {                                                       
    // TODO: Implement
}

void LiberationArmy::fight(Army *enemy, bool defense){
    // TODO: Implement
}

string LiberationArmy::str() const {
    // TODO: Implement
}


// Sup function
int LiberationArmy::nearestFibonacci(int value) {
    // TODO: Implement
}

vector<Unit*> LiberationArmy::knapsack(vector<Unit*> units, int minScore) {
    // TODO: Implement
}

Unit* LiberationArmy::cloneUnit(Unit* unit) {
    // TODO: Implement
}