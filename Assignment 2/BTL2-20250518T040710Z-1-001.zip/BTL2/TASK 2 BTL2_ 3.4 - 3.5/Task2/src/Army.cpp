#include "Army.h"

Army::Army(Unit **unitArray, int size, string name) : name(name)
{
    // TODO: Implement
}

Army::~Army() {
    // TODO: Implement
}

void Army::fight(Army* enemy, bool defense) {
    // TODO: Implement
}

string Army::str() const {
    // TODO: Implement
}

int Army::safeCeil(double value) {
    // TODO: Implement
}

void Army::updateScore(bool update){
    // TODO: Implement
}