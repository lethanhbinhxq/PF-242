#include "ARVN.h"

// TODO: Implement
ARVN::ARVN(Unit** unitArray, int size, string name)
    : Army(unitArray, size, name) {
        // TODO: Implement
}

void ARVN::fight(Army* enemy, bool defense) {
    // TODO: Implement
}

string ARVN::str() const {
    // TODO: Implement
}

void ARVN::updateScores() {
    // TODO: Implement
}