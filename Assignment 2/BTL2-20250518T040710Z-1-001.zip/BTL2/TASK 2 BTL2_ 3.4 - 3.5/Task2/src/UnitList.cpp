#include "UnitList.h"

UnitList::UnitList(int S) : countInfantry(0), countVehicle()
{
    // TODO: Implement
}

bool UnitList::insert(Unit *unit)
{
    // TODO: Implement
}

bool UnitList::isContain(VehicleType vehicleType)
{
    // TODO: Implement
}

bool UnitList::isContain(InfantryType infantryType)
{
    // TODO: Implement
}

string UnitList::str() const
{
    // TODO: Implement
}

void UnitList::remove(Unit *unit) {
    // TODO: Implement
}

